This is the custom education-focused dataset for WANG Yujia's final year project.

Project code: 21CS149

Detailed construction rules of the dataset is discussed in the report.

This dataset contains 100 training, 25 dev and 25 test samples.

All the labels and user utterance are created by Wang Yujia according to real life experiences and common knowledge.

The Details of model training please refer to: https://github.com/monologg/JointBERT.