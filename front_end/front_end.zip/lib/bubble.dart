import 'package:flutter/material.dart';

abstract class Bubble extends StatefulWidget{
  const Bubble({Key? key}) : super(key: key);
}