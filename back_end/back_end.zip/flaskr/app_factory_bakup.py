import os
from flask import Flask, request
# from predict_a_line import predict_main


def create_app(test_config=None):
    # create and configure the app
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        SECRET_KEY='dev',
        DATABASE=os.path.join(app.instance_path, 'flaskr.sqlite'),
    )

    if test_config is None:
        # load the instance config, if it exists, when not testing
        app.config.from_pyfile('config.py', silent=True)
    else:
        # load the test config if passed in
        app.config.from_mapping(test_config)

    # ensure the instance folder exists
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass

    # a simple page that says hello
    @app.route("/")
    @app.route('/hello')
    def hello():
        return 'Hello, this is a chatbot! What can I do for you?'

    @app.route('/respond', methods=['POST'])
    def respond():
        # data = request.json['input']
        print(request.form)
        print(request.form['input'])
        # print(predict_main(request.form['input']))
        # res = predict_a_line(data)
        # slot_str = ''
        # for s in data.slots:
        #     slot_str += s.pred + ": " + s.word + '\n'
        # return f'Intent:{data.intent},\nslots: {slot_str}'
        # return 'A dummy respond!'
        return request.form['input']

    return app


create_app()

# set env in terminal:
# > venv\Scripts\activate
# cd flaskr
# > $env:FLASK_APP='__init__.py'
# > $env:FLASK_ENV='development'
# > flask run
